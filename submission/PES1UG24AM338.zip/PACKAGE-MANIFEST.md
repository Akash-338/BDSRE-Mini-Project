# Package manifest

## Team

- Akash Kiran Vernekar (PES1UG24AM338)
- Anish A Kunder (PES1UG24AM343)

## Included

- README with system architecture, Windows setup, and full reproduction commands.
- Python source scripts, unit tests, and one Python 3.12 CI workflow.
- Results notebook, benchmark protocol, data card, tuning playbook, and 3-page technical report.
- Three-minute demo MP4 with disclosed computer-generated narration, editable slides, and narration script.

## Regenerate generated data

Generated Parquet inputs, raw benchmark/audit JSON, executed notebook output, caches, and virtual environments are excluded. Run the sequential PowerShell commands in README.md to regenerate them. The experiment uses synthetic TPC-H lineitem data; the recorded figures remain in the tuning playbook and report.

## Validation for this package build

- Python 3.12 CI dependency set: 31 unit tests passed with duckdb 2.0.0.
- Spark/Delta smoke test passed: 6,005 TPC-H rows and Delta files 4 -> 1 -> 1.
- End-to-end sample: 6,005 rows, 61 Parquet micro-batch files, 61/61 governance files passed, result notebook executed.
- Demo MP4: 180.595 seconds with video and audio tracks.

Energy is scenario-estimated from assumed system power; it is not meter-measured. The custom Morton layout is not native DuckDB Z-ordering. The governance audit is not a privacy guarantee. This is not an official TPC-H benchmark.
