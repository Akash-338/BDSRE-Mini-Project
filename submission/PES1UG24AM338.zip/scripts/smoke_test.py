"""Small stack smoke test; keeps generated files under the selected tools root."""
import os
from pathlib import Path
import tempfile
from urllib.request import urlretrieve

import duckdb
from pyspark.sql import SparkSession
from delta.tables import DeltaTable


tools_root = Path(os.environ.get("BDSRE_TOOLS_ROOT", ".tools")).resolve()
smoke_base = tools_root / "smoke"
smoke_base.mkdir(parents=True, exist_ok=True)
root = Path(tempfile.mkdtemp(prefix="run-", dir=smoke_base))

# Use direct classpath jars instead of Spark Packages so Windows does not copy
# loaded JARs into a temporary directory that Spark cannot delete at shutdown.
version = "3.3.2"
artifacts = {
    "io.delta_delta-spark_2.12-3.3.2.jar": "https://repo.maven.apache.org/maven2/io/delta/delta-spark_2.12/3.3.2/delta-spark_2.12-3.3.2.jar",
    "io.delta_delta-storage-3.3.2.jar": "https://repo.maven.apache.org/maven2/io/delta/delta-storage/3.3.2/delta-storage-3.3.2.jar",
}
existing = tools_root / "cache" / "ivy" / "jars"
if all((existing / name).is_file() for name in artifacts):
    delta_jars = [existing / name for name in artifacts]
else:
    jar_cache = tools_root / "cache" / "delta-jars"
    jar_cache.mkdir(parents=True, exist_ok=True)
    delta_jars = []
    for name, url in artifacts.items():
        jar = jar_cache / name
        if not jar.is_file() or jar.stat().st_size == 0:
            temporary = jar.with_suffix(jar.suffix + ".download")
            urlretrieve(url, temporary)
            temporary.replace(jar)
        delta_jars.append(jar)
classpath = os.pathsep.join(str(jar) for jar in delta_jars)
os.environ["PYSPARK_SUBMIT_ARGS"] = (
    f'--driver-class-path "{classpath}" '
    f'--conf "spark.executor.extraClassPath={classpath}" pyspark-shell'
)

# Generate the TPC-H sample with DuckDB in this isolated run folder.
db = duckdb.connect()
ext_dir = root / "duckdb-extensions"
db.execute(f"SET extension_directory='{ext_dir.as_posix()}'")
db.execute("INSTALL tpch")
db.execute("LOAD tpch")
db.execute("CALL dbgen(sf=0.001)")
rows = db.execute("SELECT count(*) FROM lineitem").fetchone()[0]
db.close()
assert rows == 6005, rows

builder = (SparkSession.builder.master("local[2]").appName("BDSRE-stack-smoke")
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    .config("spark.sql.shuffle.partitions", "2")
    .config("spark.databricks.delta.snapshotPartitions", "2")
    .config("spark.databricks.delta.optimize.maxFileSize", "1048576"))
spark = builder.getOrCreate()
spark.sparkContext.setLogLevel("ERROR")
try:
    table_path = (root / "delta-table").as_posix()
    for i in range(4):
        (spark.range(i * 100, (i + 1) * 100)
         .selectExpr("id", "id % 10 AS group_id").coalesce(1)
         .write.format("delta").mode("append").save(table_path))
    table = DeltaTable.forPath(spark, table_path)

    def summary():
        frame = spark.read.format("delta").load(table_path)
        return (frame.count(), frame.selectExpr("sum(id) AS total").first().total,
                len(frame.inputFiles()))

    before = summary()
    table.optimize().executeCompaction()
    compacted = summary()
    table.optimize().executeZOrderBy("group_id", "id")
    zordered = summary()
    assert before[:2] == compacted[:2] == zordered[:2] == (400, 79800)
    assert compacted[2] < before[2], (before, compacted)
    print(f"TPC-H rows={rows}; files: {before[2]} -> {compacted[2]} -> {zordered[2]}")
finally:
    spark.stop()
